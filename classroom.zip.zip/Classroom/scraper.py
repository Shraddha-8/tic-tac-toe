import requests
from bs4 import BeautifulSoup
import time # Use this to avoid getting blocked by the website

# Step 1: Ek page se saare laptops ke links nikaalna
url = "https://www.flipkart.com/laptops/pr?sid=6bo,b5g"
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')

laptop_links = []
# Sahi class name dhoondhne ke baad isko update karein
# New, more reliable code for finding links
all_product_cards = soup.find_all('div', class_='_4rR01T')

laptop_links = []
for card in all_product_cards:
    link_tag = card.find('a')
    if link_tag:
        full_url = "https://www.flipkart.com" + link_tag.get('href')
        laptop_links.append(full_url)

print(f"Total {len(laptop_links)} laptops found. Now starting to scrape details...")

# Step 2: Har link par jaakar price aur naam nikalna
# Ab hum har link par jaakar data scrape karenge
for product_url in laptop_links:
    try:
        # Ek product page ka data maangein
        product_response = requests.get(product_url)
        product_soup = BeautifulSoup(product_response.content, 'html.parser')

        # Sahi class names yahaan update karein jo aapne 'Inspect' se dhundi hain
        product_name = product_soup.find('span', class_='_4rR01T').text 
        product_price = product_soup.find('div', class_='_30jeq3 _16Jk6d').text

        print(f"Product Name: {product_name}")
        print(f"Product Price: {product_price}")
        print("---")
        
        time.sleep(2) # 2-second ka gap taaki block na ho
        
    except Exception as e:
        print(f"Error scraping {product_url}: {e}")